---
name: Bug report
about: Report a connection, DPI, button, or UI problem
labels: ''
---

## What happened?
Describe what you expected and what actually happened.

## Steps to reproduce
1.
2.
3.

## System
- Distribution / version:
- Desktop: KDE / GNOME / other
- Wayland or X11:
- Mouse: G502 X wired / LIGHTSPEED / PLUS / other
- Connection: cable / receiver
- App version or commit:
- Kernel (`uname -r`):
- libratbag version (`pacman -Q libratbag`):

## Diagnostics
Paste the app's error and `ratbagctl list` output. If relevant, include
`journalctl -u ratbagd -b --no-pager -n 80`.
Remove usernames, hostnames, serial numbers, and unrelated private data before posting.

## Hardware verification
Does the same operation work in Piper or ratbagctl?
