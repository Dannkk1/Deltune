---
name: Feature request
about: Suggest a useful mouse control or usability improvement
labels: ''
---

## Problem
What are you trying to do?

## Proposed behavior
How should it work?

## Hardware
Which mouse model and connection type would use this feature?
