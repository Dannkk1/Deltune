## Change
Explain the problem and the resulting behavior.

## Verification
- Automated checks run:
- Real mouse model / connection tested (or "not hardware-tested"):
- Limitations or driver dependencies:
